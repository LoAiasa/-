package com.bean;

public class logisticsBean {

//    CREATE TABLE `logistics`(
//    id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
//            `oddnumbers` VARCHAR(255) NOT NULL,
//    sender VARCHAR(255) NOT NULL,
//    senderPhone VARCHAR(255) NOT NULL,
//    addressee VARCHAR(255) NOT NULL,
//    addresseePhone VARCHAR(255) NOT NULL,
//    logistics VARCHAR(255) NOT NULL,
//`position` VARCHAR(255) NOT NULL,
//`time` DATE NOT NULL,
//    state CHAR NOT NULL)
    private Integer id;//物流id
    private String userId;//用户身份证号
    private String oddnumbers;//物流单号
    private String sender;//寄件人
    private String senderPhone;//寄件人电话
    private String addressee;//收件人
    private String addresseePhone;//收件人电话
    private String logistics;//承运公司
    private String position;//存放位置
    private String time;//存放时间
    private String state;//存取状态 0-未取 1-取出 2-运送中

    public logisticsBean() {
    }


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public logisticsBean(Integer id, String oddnumbers, String sender, String senderPhone, String addressee, String addresseePhone, String logistics, String position, String time, String state) {
        this.id = id;
        this.oddnumbers = oddnumbers;
        this.sender = sender;
        this.senderPhone = senderPhone;
        this.addressee = addressee;
        this.addresseePhone = addresseePhone;
        this.logistics = logistics;
        this.position = position;
        this.time = time;
        this.state = state;
    }

    public logisticsBean(Integer id, String userId, String oddnumbers, String sender, String senderPhone, String addressee, String addresseePhone, String logistics, String position, String time, String state) {
        this.id = id;
        this.userId = userId;
        this.oddnumbers = oddnumbers;
        this.sender = sender;
        this.senderPhone = senderPhone;
        this.addressee = addressee;
        this.addresseePhone = addresseePhone;
        this.logistics = logistics;
        this.position = position;
        this.time = time;
        this.state = state;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOddnumbers() {
        return oddnumbers;
    }

    public void setOddnumbers(String oddnumbers) {
        this.oddnumbers = oddnumbers;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getSenderPhone() {
        return senderPhone;
    }

    public void setSenderPhone(String senderPhone) {
        this.senderPhone = senderPhone;
    }

    public String getAddressee() {
        return addressee;
    }

    public void setAddressee(String addressee) {
        this.addressee = addressee;
    }

    public String getAddresseePhone() {
        return addresseePhone;
    }

    public void setAddresseePhone(String addresseePhone) {
        this.addresseePhone = addresseePhone;
    }

    public String getLogistics() {
        return logistics;
    }

    public void setLogistics(String logistics) {
        this.logistics = logistics;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "logisticsBean{" +
                "id=" + id +
                ", oddnumbers='" + oddnumbers + '\'' +
                ", sender='" + sender + '\'' +
                ", senderPhone='" + senderPhone + '\'' +
                ", addressee='" + addressee + '\'' +
                ", addresseePhone='" + addresseePhone + '\'' +
                ", logistics='" + logistics + '\'' +
                ", position='" + position + '\'' +
                ", time=" + time +
                ", state=" + state +
                '}';
    }
}
