package com.bean;

public class UserBean {
  private Integer id;
  private String userId;//用户身份证号
  private String userName;
  private String passWard;
  private String phone;
  private String addr;


  public UserBean(Integer id, String userId, String userName, String passWard, String phone, String addr) {
    this.id = id;
    this.userId = userId;
    this.userName = userName;
    this.passWard = passWard;
    this.phone = phone;
    this.addr = addr;
  }


  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public UserBean(Integer id, String userName, String passWard) {
    this.id = id;
    this.userName = userName;
    this.passWard = passWard;
  }

  public UserBean(Integer id, String userName, String passWard, String phone, String addr) {
    this.id = id;
    this.userName = userName;
    this.passWard = passWard;
    this.phone = phone;
    this.addr = addr;
  }

  public UserBean() {
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getPassWard() {
    return passWard;
  }

  public void setPassWard(String passWard) {
    this.passWard = passWard;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getAddr() {
    return addr;
  }

  public void setAddr(String addr) {
    this.addr = addr;
  }
  // TODO: 2022/12/18

  @Override
  public String toString() {
    return "UserBean{" +
            "id=" + id +
            ", userName='" + userName + '\'' +
            ", passWard='" + passWard + '\'' +
            ", phone='" + phone + '\'' +
            ", addr='" + addr + '\'' +
            '}';
  }
}
