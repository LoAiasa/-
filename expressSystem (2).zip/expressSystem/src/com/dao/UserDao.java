package com.dao;

import com.bean.UserBean;

import java.sql.SQLException;

public class UserDao extends BasicDAO<UserBean>{

  //注册用户
  public int addUser(UserBean UserBean){
    //sql
    String sql = "INSERT INTO user VALUES(NULL,?,?,MD5(?),?,?)";
    int update = 0;
    try {
      update = update(sql,UserBean.getUserId(), UserBean.getUserName(), UserBean.getPassWard(),UserBean.getPhone(),UserBean.getAddr());
    } catch (SQLException e) {
      System.out.println("注册用户失败");
      e.printStackTrace();
    }
    return update;
  }
  //查询用户 根据用户名
  public int queryUserUser(String userName){
    //sql
    String sql = "SELECT * FROM user WHERE userName = ?";
    Object name = queryScalar(sql, userName);
    System.out.println(name);
    if (!(null == name)){
      return (int)name;
    }
    return 0;
  }

  public UserBean queryLogin(UserBean userBean){
    //sql
    String sql = "SELECT * FROM user WHERE userName = ? AND passWard = MD5(?)";
    UserBean UserBean= null;
    try {
      UserBean = querySingle(sql, UserBean.class, userBean.getUserName(), userBean.getPassWard());
    } catch (SQLException e) {
      System.out.println("登录失败");
    }
    return UserBean;
  }

}
