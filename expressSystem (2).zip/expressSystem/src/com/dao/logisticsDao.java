package com.dao;

import com.bean.logisticsBean;

import java.sql.SQLException;
import java.util.List;

public class logisticsDao extends BasicDAO<logisticsBean>{
    //查询物流单 根据单号
    public  logisticsBean queryLogisticsByoddnumbers(String oddnumbers) throws SQLException {
        //sql
        String sql = "SELECT * FROM logistics WHERE oddnumbers = ?";
        logisticsBean logisticsBean = querySingle(sql, logisticsBean.class, oddnumbers);

        if (!(null == logisticsBean)){
            return logisticsBean;
        }
        return null;
    }

    //查询所有
    public  List<logisticsBean> queryLogisticsAll() throws SQLException {
        //sql
        String sql = "SELECT * FROM logistics";
        List<logisticsBean> logisticsBeans = queryMulti(sql, logisticsBean.class);


        return logisticsBeans;
    }
    //添加物流信息
    public void addLogistics(logisticsBean logisticsBean) throws SQLException {
        String sql = "INSERT INTO logistics VALUES(NULL,?,?,?,?,?,?,?,?,?,?)";
        update(sql,logisticsBean.getUserId(),logisticsBean.getOddnumbers(),logisticsBean.getSender(),logisticsBean.getSenderPhone(),
                logisticsBean.getAddressee(),logisticsBean.getAddresseePhone(),logisticsBean.getLogistics(),logisticsBean.getPosition(),
                logisticsBean.getTime(),logisticsBean.getState());

    }

    //根据订单号删除
    public int delLogisticeByNum(String oddnumbers) throws SQLException {
        String sql = "DELETE FROM `logistics` WHERE oddnumbers = ?";
        int update = update(sql, oddnumbers);
        return update;
    }

    //根据快递单号或者收件人姓名或者电话查询
    public List<logisticsBean> select(logisticsBean logisticsBean) throws SQLException {
        String sql = "SELECT * FROM logistics WHERE oddnumbers=? OR addressee = ? OR addresseePhone = ?";
            return     queryMulti(sql, com.bean.logisticsBean.class, logisticsBean.getOddnumbers(), logisticsBean.getAddressee(), logisticsBean.getAddresseePhone());
    }

    //修改
    public int update(logisticsBean logisticsBean) throws SQLException {
        String sql = "UPDATE `logistics` SET sender=?,senderPhone=?,addressee=?,addresseePhone=?,logistics=?,`position`=?,`time`=?,state=? WHERE oddnumbers=?";

        return update(sql,logisticsBean.getSender(),logisticsBean.getSenderPhone(),
                logisticsBean.getAddressee(),logisticsBean.getAddresseePhone(),logisticsBean.getLogistics(),logisticsBean.getPosition(),
                logisticsBean.getTime(),logisticsBean.getState(),logisticsBean.getOddnumbers());
    }

    //根据身份证号查询
    public List<logisticsBean> selectLbByUserId(String UserId){
    String sql="SELECT * FROM logistics WHERE userId=? ";
        return queryMulti(sql, logisticsBean.class, UserId);
    }

}
