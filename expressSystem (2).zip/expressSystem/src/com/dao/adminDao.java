package com.dao;

import com.bean.adminBean;

import java.sql.SQLException;

public class adminDao extends BasicDAO<adminBean>{


  //注册用户
  public int addAdminUser(adminBean adminBean){
    //sql
    String sql = "INSERT INTO admin VALUES(NULL,?,MD5(?))";
    int update = 0;
    try {
      update = update(sql, adminBean.getUserName(), adminBean.getPassWard());
    } catch (SQLException e) {
      System.out.println("注册用户失败");
    }
    return update;
  }
  //查询用户 根据用户名
  public int queryAdminUser(String userName){
    //sql
    String sql = "SELECT * FROM admin WHERE userName = ?";
    Object name = queryScalar(sql, userName);
    System.out.println(name);
    if (!(null == name)){
      return (int)name;
    }
    return 0;
  }

  public adminBean queryLogin(adminBean ab){
    //sql
    String sql = "SELECT * FROM admin WHERE userName = ? AND passWard = MD5(?)";
    adminBean adminBean= null;
    try {
      adminBean = querySingle(sql, adminBean.class, ab.getUserName(), ab.getPassWard());
    } catch (SQLException e) {
      System.out.println("登录失败");
    }
    return adminBean;
  }

}
