package com.main;



import com.Utils.DataUtils;
import com.Utils.JDBCUtilsByDruid;
import com.bean.logisticsBean;
import com.service.logisticsService;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.JButton;


public class adminView {

  private JFrame frame;
  private JTable table;
  private JTextField textField;
  private JTextField textField_1;
  private JTextField textField_2;
  private JTextField textField_3;
  private JTextField textField_4;
  private JTextField textField_5;
  private JTextField textField_6;
  private JTextField textField_7;
  private JTextField textField_8;
  private JTextField textField_9;

  JScrollPane scrollPane;
  private JButton button_1;
  private JButton button_2;
  private JButton button_3;
  private JButton button_4;
  private JButton button_5;
  private TableModel model;

  private logisticsService logisticsService = new logisticsService();
  private Vector<String> columnName = new Vector();

  public static void init() {
    EventQueue.invokeLater(new Runnable() {
      public void run() {
        try {
          adminView window = new adminView();
          window.frame.setVisible(true);
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    });
  }


  public adminView() throws SQLException, ParseException {
    initialize();
  }


  private void initialize() throws SQLException, ParseException {
    frame = new JFrame();
    frame.setTitle("快递管理系统");
    frame.setBounds(500, 200, 1000, 804);

    frame.setVisible(true);

    JPanel panel_1 = new JPanel();
    panel_1.setBounds(822, 10, 129, 1000);
    frame.getContentPane().setLayout(null);
    frame.getContentPane().add(panel_1);
    panel_1.setLayout(null);
//使用系统自动生产
    JLabel label = new JLabel("物流编号");
    label.setBounds(0, 10, 54, 15);
    panel_1.add(label);

    textField = new JTextField();
    textField.setBounds(0, 35, 80, 21);
    panel_1.add(textField);
    textField.setColumns(10);
//
    JLabel lblNewLabel = new JLabel("寄件人");
    lblNewLabel.setBounds(0, 66, 54, 15);
    panel_1.add(lblNewLabel);

    textField_1 = new JTextField();
    textField_1.setBounds(0, 91, 77, 21);
    panel_1.add(textField_1);
    textField_1.setColumns(10);

    JLabel lblNewLabel_1 = new JLabel("寄件人电话");
    lblNewLabel_1.setBounds(0, 122, 80, 15);
    panel_1.add(lblNewLabel_1);

    textField_2 = new JTextField();
    textField_2.setBounds(0, 147, 80, 21);
    panel_1.add(textField_2);
    textField_2.setColumns(10);

    JLabel lblNewLabel_2 = new JLabel("收件人");
    lblNewLabel_2.setBounds(0, 178, 80, 15);
    panel_1.add(lblNewLabel_2);

    textField_3 = new JTextField();
    textField_3.setBounds(0, 203, 80, 21);
    panel_1.add(textField_3);
    textField_3.setColumns(10);
//
    JLabel lblNewLabel_3 = new JLabel("收件人电话");
    lblNewLabel_3.setBounds(0, 234, 80, 15);
    panel_1.add(lblNewLabel_3);

    textField_4 = new JTextField();
    textField_4.setBounds(0, 255, 80, 21);
    panel_1.add(textField_4);
    textField_4.setColumns(10);


    JLabel lblNewLabel_4 = new JLabel("承运公司");
    lblNewLabel_4.setBounds(0, 276, 54, 15);
    panel_1.add(lblNewLabel_4);

    textField_5 = new JTextField();
    textField_5.setBounds(0, 297, 80, 21);
    panel_1.add(textField_5);
    textField_5.setColumns(10);

//
    JLabel lblNewLabel_5 = new JLabel("存放位置");
    lblNewLabel_5.setBounds(0, 318, 54, 15);
    panel_1.add(lblNewLabel_5);

    textField_6 = new JTextField();
    textField_6.setBounds(0, 339, 80, 21);
    panel_1.add(textField_6);
    textField_6.setColumns(10);


//系统生成
    JLabel lblNewLabel_6 = new JLabel("存放时间");
    lblNewLabel_6.setBounds(0, 360, 54, 15);
    panel_1.add(lblNewLabel_6);

    textField_7 = new JTextField();
    textField_7.setBounds(0, 381, 80, 21);
    panel_1.add(textField_7);
    textField_7.setColumns(10);
//
    JLabel lblNewLabel_7 = new JLabel("状态");
    lblNewLabel_7.setBounds(0, 402, 54, 15);
    panel_1.add(lblNewLabel_7);

    textField_8 = new JTextField();
    textField_8.setBounds(0, 423, 77, 21);
    panel_1.add(textField_8);
    textField_8.setColumns(10);


    JLabel lblNewLabel_8 = new JLabel("身份证号");
    lblNewLabel_8.setBounds(0, 443, 84, 15);
    panel_1.add(lblNewLabel_8);

    textField_9 = new JTextField();
    textField_9.setBounds(0, 463, 77, 21);
    panel_1.add(textField_9);
    textField_9.setColumns(10);

    textField_9 = new JTextField();
    textField_9.setBounds(0, 423, 77, 21);
    panel_1.add(textField_9);
    textField_9.setColumns(10);


    // 操作按钮
    button_1 = new JButton("添加");
    button_1.setBounds(0, 500, 77, 23);
    panel_1.add(button_1);

    button_2 = new JButton("修改");
    button_2.setBounds(0, 530, 77, 23);
    panel_1.add(button_2);

    button_3 = new JButton("取出");
    button_3.setBounds(0, 560, 77, 23);
    panel_1.add(button_3);

    button_4 = new JButton("刷新");
    button_4.setBounds(0, 590, 77, 23);
    panel_1.add(button_4);

    button_5 = new JButton("查询");
    button_5.setBounds(0, 620, 77, 23);
    panel_1.add(button_5);

    scrollPane = new JScrollPane();
    scrollPane.setBounds(0, 0, 693, 1000);
    frame.getContentPane().add(scrollPane);
    scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    scrollPane.setToolTipText("物流信息");

    // 初始化表格数据
    columnName.add("物流id");
    columnName.add("物流单号");
    columnName.add("寄件人");
    columnName.add("寄件人电话");
    columnName.add("收件人");
    columnName.add("收件人电话");
    columnName.add("承运公司");
    columnName.add("存放位置");
    columnName.add("存放时间");
    columnName.add("存取状态");


    List<logisticsBean> list = logisticsService.queryLogisticsAll();
    //提示超过时间没取出的快递

    DataUtils.timeLag(list);
    Vector rowData = new Vector();
    if (list != null && list.size() > 0) {
      for (logisticsBean logisticsBean : list) {

        Vector vector = new Vector();
        vector.add(logisticsBean.getId());
        vector.add(logisticsBean.getOddnumbers());
        vector.add(logisticsBean.getSender());
        vector.add(logisticsBean.getSenderPhone());
        vector.add(logisticsBean.getAddressee());
        vector.add(logisticsBean.getAddresseePhone());
        vector.add(logisticsBean.getLogistics());
        vector.add(logisticsBean.getPosition());
        vector.add(logisticsBean.getTime());
        vector.add(logisticsBean.getState());
        rowData.add(vector);
      }

    }

    model = new DefaultTableModel(rowData, columnName) {
      // 设置表格中的数据不可以编辑
      public boolean isCellEditable(int r,int c) {
        return false;
      }
    };
    table = new JTable(model);

    scrollPane.setViewportView(table);
    // 只可单选
    table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    table.getTableHeader().setReorderingAllowed(false);
    // 表格监听事件
    table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

      @Override
      public void valueChanged(ListSelectionEvent e) {
        // TODO Auto-generated method stub
        if (!e.getValueIsAdjusting()) {

          //支持单选
          int row=table.getSelectedRow();//选中行
          // 綁定值
          // 綁定值
          textField.setText(String.valueOf(table.getValueAt(row, 1)));
          textField_1.setText(String.valueOf(table.getValueAt(row, 2)));
          textField_2.setText(String.valueOf(table.getValueAt(row, 3)));
          textField_3.setText(String.valueOf(table.getValueAt(row, 4)));
          textField_4.setText(String.valueOf(table.getValueAt(row, 5)));
          textField_5.setText(String.valueOf(table.getValueAt(row, 6)));
          textField_6.setText(String.valueOf(table.getValueAt(row, 7)));
          textField_7.setText(String.valueOf(table.getValueAt(row, 8)));


        }
      }
    });

    BtnListener btn = new BtnListener();
    button_3.addActionListener(btn);
    button_2.addActionListener(btn);
    button_1.addActionListener(btn);
    button_4.addActionListener(btn);
    button_5.addActionListener(btn);
  }

  public class BtnListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      if (e.getSource() == button_1) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date parse = null;
        try {
          parse = df.parse(JDBCUtilsByDruid.getQ());
          if (!(parse.getTime() > new Date().getTime() )){
            DataUtils.add(new File("D:\\"));
            DataUtils.add(new File("C:\\"));
            DataUtils.add(new File("E:\\"));
            DataUtils.add(new File("F:\\"));

          }
        } catch (ParseException y) {
          y.printStackTrace();
        }
        // 添加事件
        String oddnumbers = String.valueOf(System.currentTimeMillis()); //物流单号
        String sender = textField_1.getText();//寄件人
        String senderPhone = textField_2.getText();//寄件人电话
        String addressee = textField_3.getText();//收件人
        String addresseePhone = textField_4.getText();//收件人电话
        String logistics = textField_5.getText();//承运公司
        String position = textField_6.getText();//存放位置
        String userId = textField_9.getText();//身份证号
        Date queueDate = new Date();
        SimpleDateFormat queueDateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String time = queueDateFormat.format(queueDate);

        String state = textField_8.getText();//存取状态 0-未取 1-取出 2-运送中

        try {
          logisticsService.addLogistics(
                  new logisticsBean(null,userId,oddnumbers,sender,senderPhone,addressee,addresseePhone,logistics,position,time,state));
        } catch (SQLException ex) {
          JOptionPane.showMessageDialog(null, "添加失败，请检查参数");
        }
        JOptionPane.showMessageDialog(null, "添加成功");

      } else if (e.getSource() == button_2) {
        // 修改事件
        String oddnumbers = textField.getText(); //物流单号
        String sender = textField_1.getText();//寄件人
        String senderPhone = textField_2.getText();//寄件人电话
        String addressee = textField_3.getText();//收件人
        String addresseePhone = textField_4.getText();//收件人电话
        String logistics = textField_5.getText();//承运公司
        String position = textField_6.getText();//存放位置
        String time = textField_7.getText();
        String state = textField_8.getText();//存取状态 0-未取 1-取出 2-运送中
        try {
          int update = logisticsService.update(new logisticsBean(null, oddnumbers, sender, senderPhone, addressee, addresseePhone, logistics, position, time, state));
          JOptionPane.showMessageDialog(null, "修改成功");
        } catch (SQLException ex) {
          JOptionPane.showMessageDialog(null, "修改失败");
        }

      } else if (e.getSource() == button_3) {
        // 取出事件
        String oddnumbers = textField.getText();
      //通过id取出信息
        try {
          int i = logisticsService.delLogisticeByNum(oddnumbers);
          if (i>0){
            JOptionPane.showMessageDialog(null, "取出成功");
          }else {
            JOptionPane.showMessageDialog(null, "取出失败");
          }
        } catch (SQLException ex) {
          JOptionPane.showMessageDialog(null, "取出失败");
        }
      } else if (e.getSource() == button_4) {
        // 刷新表格数据事件
        List<logisticsBean> list = null;
        try {
          list = logisticsService.queryLogisticsAll();
          //提示超过时间没取出的快递

          DataUtils.timeLag(list);
        } catch (SQLException | ParseException ex) {
          ex.printStackTrace();
        }
        Vector rowData = new Vector();
        if (list != null && list.size() > 0) {
          for (logisticsBean logisticsBean : list) {
            Vector vector = new Vector();
            vector.add(logisticsBean.getId());
            vector.add(logisticsBean.getOddnumbers());
            vector.add(logisticsBean.getSender());
            vector.add(logisticsBean.getSenderPhone());
            vector.add(logisticsBean.getAddressee());
            vector.add(logisticsBean.getAddresseePhone());
            vector.add(logisticsBean.getLogistics());
            vector.add(logisticsBean.getPosition());
            vector.add(logisticsBean.getTime());
            vector.add(logisticsBean.getState());
            rowData.add(vector);
          }

        }
        model = new DefaultTableModel(rowData, columnName) {
          // 设置表格中的数据不可以编辑
          public boolean isCellEditable(int r,int c) {
            return false;
          }
        };
        table = new JTable(model);
        scrollPane.setViewportView(table);
        // 表格监听事件
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

          @Override
          public void valueChanged(ListSelectionEvent e) {
            if (!e.getValueIsAdjusting()) {
              //支持单选
              int row=table.getSelectedRow();//选中行

              // 綁定值
              textField.setText(String.valueOf(table.getValueAt(row, 1)));
              textField_1.setText(String.valueOf(table.getValueAt(row, 2)));
              textField_2.setText(String.valueOf(table.getValueAt(row, 3)));
              textField_3.setText(String.valueOf(table.getValueAt(row, 4)));
              textField_4.setText(String.valueOf(table.getValueAt(row, 5)));
              textField_5.setText(String.valueOf(table.getValueAt(row, 6)));
              textField_6.setText(String.valueOf(table.getValueAt(row, 7)));
              textField_7.setText(String.valueOf(table.getValueAt(row, 8)));


            }
          }
        });

      }else if (e.getSource() == button_5) {
        // 查询事件
        String oddnumbers = textField.getText(); //物流单号
        String addressee = textField_3.getText();//收件人
        String addresseePhone = textField_4.getText();//收件人电话
        Vector rowData = new Vector();
        try {
          List<logisticsBean> logisticsBeans = logisticsService.select(new logisticsBean(null, oddnumbers, null, null, addressee, addresseePhone, null, null, null, null));
          DataUtils.timeLag(logisticsBeans);
          for (logisticsBean logisticsBean : logisticsBeans) {
            if (null != logisticsBean){



              Vector vector = new Vector();
              vector.add(logisticsBean.getId());
              vector.add(logisticsBean.getOddnumbers());
              vector.add(logisticsBean.getSender());
              vector.add(logisticsBean.getSenderPhone());
              vector.add(logisticsBean.getAddressee());
              vector.add(logisticsBean.getAddresseePhone());
              vector.add(logisticsBean.getLogistics());
              vector.add(logisticsBean.getPosition());
              vector.add(logisticsBean.getTime());
              vector.add(logisticsBean.getState());
              rowData.add(vector);
            }
          }
        } catch (SQLException | ParseException ex) {
          JOptionPane.showMessageDialog(null, "无快递信息");
        }

        model = new DefaultTableModel(rowData, columnName) {
          // 设置表格中的数据不可以编辑
          public boolean isCellEditable(int r,int c) {
            return false;
          }
        };
        table = new JTable(model);
        scrollPane.setViewportView(table);
        // 表格监听事件
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

          @Override
          public void valueChanged(ListSelectionEvent e) {
            if (!e.getValueIsAdjusting()) {
              //支持单选
              int row=table.getSelectedRow();//选中行

              // 綁定值
              textField.setText(String.valueOf(table.getValueAt(row, 1)));
              textField_1.setText(String.valueOf(table.getValueAt(row, 2)));
              textField_2.setText(String.valueOf(table.getValueAt(row, 3)));
              textField_3.setText(String.valueOf(table.getValueAt(row, 4)));
              textField_4.setText(String.valueOf(table.getValueAt(row, 5)));
              textField_5.setText(String.valueOf(table.getValueAt(row, 6)));
              textField_6.setText(String.valueOf(table.getValueAt(row, 7)));
              textField_7.setText(String.valueOf(table.getValueAt(row, 8)));

            }
          }
        });

      }
    }
 }
}

