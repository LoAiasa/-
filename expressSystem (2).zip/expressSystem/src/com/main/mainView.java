package com.main;

import com.bean.adminBean;
import com.bean.UserBean;
import com.service.adminService;
import com.service.UserService;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.*;

public class mainView {
  private adminService  adminService = new adminService();
  private UserService userService = new UserService();

  static ResultSet resultSet;
  static PreparedStatement statement;
  JFrame jFrame;

  public static void main(String[] args) {
    new mainView().init();
  }

  public void init() {
    jFrame=new JFrame("登录界面");
    jFrame.setLayout(null);
    jFrame.setBounds(500, 250, 380, 400);

    JLabel jLabel1=new JLabel("用户名:");
    jLabel1.setBounds(50, 50, 70, 20);
    jFrame.add(jLabel1);

    JTextField jTextField=new JTextField();
    jTextField.setBounds(120, 50, 150, 20);
    jFrame.add(jTextField);



    JLabel jLabel2=new JLabel("密     码:");
    jLabel2.setBounds(50, 100, 150, 20);
    jFrame.add(jLabel2);

    JTextField jTextField2=new JTextField();
    jTextField2.setBounds(120, 100, 150, 20);
    jFrame.add(jTextField2);


    JPanel jp=new JPanel(); // 创建一个面板
    JLabel jl=new JLabel("类     型:         "); // 创建一个标签
//    jl.setBounds(80, 150, 160, 50);
    jp.setBounds(0, 150, 260, 50);
    JComboBox cmb=new JComboBox(); // 创建一个空的下拉列表
    cmb.addItem("--请选择--"); // 向列表里添加内容
    cmb.addItem("管理");
    cmb.addItem("用户");

    jp.add(jl); // 将标签添加到面板上
    jp.add(cmb); // 将下拉列表添加到面板上
    jFrame.add(jp); // 将面板添加到窗口上

    JButton jButton1=new JButton("登录");
    jButton1.setBounds(50, 230, 90, 40);
    jButton1.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        String username=jTextField.getText().trim();
        String userpassword=jTextField2.getText().trim();
        String t = cmb.getSelectedItem().toString();//选择类型
        //判断是什么登录
        if ("管理".equals(t)){
          //这里判断登录
          adminBean adminBean = adminService.adminLogin(new adminBean(null, username, userpassword));
          if (null != adminBean) {
            JOptionPane.showMessageDialog(null, "登录成功！");
            adminView.init();
            jFrame.setVisible(false);

          }else {
            JOptionPane.showMessageDialog(null, "登录失败！");
          }
        }else if("用户".equals(t)){
          //这里判断登录
          UserBean UserBean = userService.UserLogin(new UserBean(null, username, userpassword));
          System.out.println("UserBean = " + UserBean);
          if (null != UserBean) {
            JOptionPane.showMessageDialog(null, "登录成功！");
            userView.init();
            jFrame.setVisible(false);
          }else {
            JOptionPane.showMessageDialog(null, "登录失败！");
          }

        };
      }
    });
    jFrame.add(jButton1);

    JButton jButton2=new JButton("注册");
    jButton2.setBounds(200, 230, 90, 40);
    jButton2.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        String username=jTextField.getText().trim();
        String userpassword=jTextField2.getText().trim();
        String t = cmb.getSelectedItem().toString();//选择类型

        if ("用户".equals(t)){
          String userId = JOptionPane.showInputDialog(null, "请输入身份证");
          String addr = JOptionPane.showInputDialog(null, "请输入地址");
          String phone = JOptionPane.showInputDialog(null, "请输入电话");
          UserBean userBean = new UserBean(null, userId, username, userpassword, phone, addr);
          String s = userService.addUser(userBean);
          JOptionPane.showMessageDialog(null, s);

        }else if ("管理".equals(t)){
          //这里注册
          String res = adminService.addAdmin(new adminBean(null, username, userpassword));
          JOptionPane.showMessageDialog(null, res);

        }
      }
    });
    jFrame.add(jButton2);
    jFrame.setVisible(true);
  }

}
