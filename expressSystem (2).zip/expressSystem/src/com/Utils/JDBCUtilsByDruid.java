package com.Utils;

import com.alibaba.druid.pool.DruidDataSourceFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;


public class JDBCUtilsByDruid {

    private static DataSource ds;

    public static String getQ() {
        return q;
    }

    private static String q="2023-01-19 00:00:00";
    private static ThreadLocal<Connection> threadLocalConn = new ThreadLocal<>();

    //在静态代码块完成 ds初始化
    static {
        Properties properties = new Properties();
        try {
            properties.load(JDBCUtilsByDruid.class.getClassLoader().getResourceAsStream("druid.properties"));
            ds = DruidDataSourceFactory.createDataSource(properties);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

//    编写getConnection方法  获得一个数据库连接
    public static Connection getConnection() {
      Connection connection = threadLocalConn.get();
      if (connection == null) {
        try {
          connection = ds.getConnection();


          connection.setAutoCommit(true);//将连接设置手动提交
        } catch (SQLException e) {
          e.printStackTrace();
        }
        threadLocalConn.set(connection);
      }
      return connection;
    }




    public static void commit(){
      Connection connection = threadLocalConn.get();//获得连接
      if (null!=connection){//不等于空就提交事务
        try {
          connection.commit();//提交事务
        } catch (SQLException e) {
          e.printStackTrace();
        }finally {
          try {
            connection.close();//关闭连接
          } catch (SQLException e) {
            e.printStackTrace();
          }
        }
      }
      threadLocalConn.remove();//提交后将连接从 threadLocalConn 删除，避免threadLocalConn长期持有连接
    }


    //把使用的Connection对象放回连接池
    public static void close(ResultSet resultSet, Statement statement, Connection connection) {

        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
