package com.service;

import com.bean.UserBean;
import com.dao.UserDao;

public class UserService {
private UserDao UserDao = new UserDao();
  public String addUser(UserBean UserBean){
    String res = "添加失败";
    int s = UserDao.queryUserUser(UserBean.getUserName());
    if (s==0){
      int i = UserDao.addUser(UserBean);
      if (i!=0){
        res = "添加成功";
      }
    }
    return res;
  }

  public UserBean UserLogin(UserBean userBean){

    UserBean UserBean = UserDao.queryLogin(userBean);

    return UserBean;
  }
}
