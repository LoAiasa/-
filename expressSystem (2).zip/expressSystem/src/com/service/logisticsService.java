package com.service;

import com.bean.logisticsBean;
import com.dao.logisticsDao;

import java.sql.SQLException;
import java.util.List;

public class logisticsService {
    private logisticsDao ld = new logisticsDao();
    public logisticsBean queryLogisticsByoddnumbers(String oddnumbers) {
        logisticsBean logisticsBean = null;
        try {
            logisticsBean = ld.queryLogisticsByoddnumbers(oddnumbers);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return logisticsBean;

    }

    //查询所有
    public List queryLogisticsAll() throws SQLException {
        List<com.bean.logisticsBean> logisticsBeans = ld.queryLogisticsAll();
        return logisticsBeans;

    }
    //添加快递
    public void addLogistics(logisticsBean logisticsBean) throws SQLException {
        ld.addLogistics(logisticsBean);
    }

    //根据订单号删除
    public int delLogisticeByNum(String oddnumbers) throws SQLException {
        return ld.delLogisticeByNum(oddnumbers);
    }


    //根据快递单号或者收件人姓名或者电话查询
    public List<logisticsBean> select(logisticsBean logisticsBean) throws SQLException {

        return ld.select(logisticsBean);
    }
    //修改
    public int update(logisticsBean logisticsBean) throws SQLException {
        return ld.update(logisticsBean);


    }

    //根据身份证号查询
    public List<logisticsBean> selectLbByUserId(String UserId){
        return ld.selectLbByUserId(UserId);
    }

}
