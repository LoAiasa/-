/**
 * 实体层
 * 中北大学（u）刘鑫
 */
package Entity;

import java.util.Date;

/**
 *
 * @author liuixin
 * @version 1.0
 */
public class ExpressInformation {
    private String expressID;//快递单号
    private String company;//快递公司
    private String name;//收件人姓名
    private String phone;//收件人电话
    private String position;//存放位置
    private String time;//存放时间

	public ExpressInformation(String expressID, String company, String name, String phone, String position, String time) {
		this.expressID = expressID;
		this.company = company;
		this.name = name;
		this.phone = phone;
		this.position = position;
		this.time = time;
	}

	public String getExpressID() {
		return expressID;
	}

	public void setExpressID(String expressID) {
		this.expressID = expressID;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
}
