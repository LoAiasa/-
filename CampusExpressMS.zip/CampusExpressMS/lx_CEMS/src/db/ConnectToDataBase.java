package db;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: LiuXin
 * @Date: 2022/12/20/0:46
 * @Description:
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectToDataBase {
    public static Connection getDataBaseConnection(){
        String driver="com.mysql.jdbc.Driver";
        String url="jdbc:mysql://localhost:3306/delivery";
        String user="root";
        String password="20010906xx";

        //加载驱动程序
        try {
            Class.forName(driver);
            //System.out.println("驱动程序加载成功");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        //链接数据库
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return conn;
    }

   /* public static void main(String[] args) {
        getDataBaseConnection();
    }*/
}

