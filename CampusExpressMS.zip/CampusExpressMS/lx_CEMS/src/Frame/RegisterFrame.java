package Frame;


import db.ConnectToDataBase;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;


public class RegisterFrame extends JFrame {
	private JLabel l_id, l_name,l_phone, l_password1, l_password2, l_sex, l_type,l_city;
	private JTextField t_id, t_name,t_phone;
	private JPasswordField p_password1, p_password2;
	ButtonGroup bg;
	private JRadioButton r_male, r_female;
	private JComboBox<String>  c_type,c_city;
	private JButton b_reg, b_reset;
	
	
	public RegisterFrame() {
		this.setTitle("注册页面");
		this.setSize(350, 450);
		this.setLocation(1050, 150);
		init();
		this.setVisible(true);
	}
	public void init() {
		this.setLayout(new GridLayout(9, 2, 5, 5));//网格布局
		l_id = new JLabel("账号", JLabel.CENTER);
		l_name = new JLabel("姓名", JLabel.CENTER);
		l_phone =new JLabel("手机号码", JLabel.CENTER);
        l_password1 = new JLabel("密码", JLabel.CENTER);
        l_password2 = new JLabel("确认密码", JLabel.CENTER);
        l_sex = new JLabel("性别", JLabel.CENTER);
		l_type = new JLabel("类别", JLabel.CENTER);
        l_city = new JLabel("城市", JLabel.CENTER);
        t_id = new JTextField();
        t_name = new JTextField();
        t_phone=new JTextField();
        
        p_password1 = new JPasswordField();
        p_password2 = new JPasswordField();
        bg = new ButtonGroup();
        r_male = new JRadioButton("男");
        r_female = new JRadioButton("女");
        bg.add(r_male);
        bg.add(r_female);
        c_city = new JComboBox<String>();
		c_city.addItem("-------------请选择------------");
        c_city.addItem("山西");
        c_city.addItem("北京");
        c_city.addItem("上海");
        c_city.addItem("成都");
        c_city.addItem("天津");

        c_type = new JComboBox<String>();
		c_type.addItem("-------------请选择------------");
		c_type.addItem("管理员");
        c_type.addItem("用户");
        b_reg = new JButton("注册");
        b_reg.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				register();
				//dispose();//关闭该窗体，释放该窗体占有的资源
			}
        	
        });
        b_reset = new JButton("重置");
        b_reset.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				t_id.setText("");
				t_name.setText("");
				t_phone.setText("");
				p_password1.setText("");
				p_password2.setText("");
				bg.clearSelection();
				c_type.setSelectedIndex(-1);
				c_city.setSelectedIndex(-1);
			}
        	
        });
        
        this.add(l_id);
        this.add(t_id);
        
        this.add(l_name);
        this.add(t_name);
        
        this.add(l_phone);
        this.add(t_phone);
        
        this.add(l_password1);
        this.add(p_password1);
        
        this.add(l_password2);
        this.add(p_password2);

		JPanel p = new JPanel();
        this.add(l_sex);  
        p.add(r_male);
        p.add(r_female);
        this.add(p);
        
        this.add(l_type);
        this.add(c_type);
        
        this.add(l_city);
        this.add(c_city);
        
        this.add(b_reg);
        this.add(b_reset);
          
        
	}
	public void register() {
//		删除字符串的头尾空白符，空白符包括：空格、制表符 tab、换行符等其他空白符等。
		String id = t_id.getText().trim();
		String name = t_name.getText().trim();
		String phone = t_phone.getText().trim();
		String password1 = p_password1.getText().trim();
		String password2 = p_password2.getText().trim();
		int x = bg.getButtonCount();
		String sex =  r_male.isSelected()?r_male.getText():r_female.getText();;
		String type = (String)c_type.getSelectedItem();
		String city = (String)c_city.getSelectedItem();
		if(!(password1.equalsIgnoreCase(password2))) {
			p_password1.setText("");
			p_password2.setText("");
			JOptionPane.showMessageDialog(null, "两次输入密码不一致"
					, "错误信息",
					JOptionPane.WARNING_MESSAGE);
			return;
		}
		try {
			Connection conn = ConnectToDataBase.getDataBaseConnection();//连接数据库
			String sql = "INSERT INTO register VALUES(?,?,?,?)";
			String sql1 = "SELECT * FROM register WHERE yonghuming = ?";
		    PreparedStatement pstm1 = conn.prepareStatement(sql1);
		    pstm1.setString(1, id);
		    ResultSet rs = pstm1.executeQuery();
			if(id.equals("") || name.equals("") || phone.equals("") || password1.equals("") || password2.equals("")){
				JOptionPane.showMessageDialog(null,"所填信息不能为空","提示信息",JOptionPane.INFORMATION_MESSAGE);
			}else {
				if (rs.next()) {
					JOptionPane.showMessageDialog(null, "注册失败!，该用户账号已存在", "提示信息", JOptionPane.INFORMATION_MESSAGE);
				} else {
					PreparedStatement pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, id);
					pstmt.setString(2, name);
					pstmt.setString(3, type);
					pstmt.setString(4, password1);
					int flag = pstmt.executeUpdate();//下达指令
					if (flag == 1) {
						JOptionPane.showMessageDialog(null, "注册成功!", "提示信息", JOptionPane.INFORMATION_MESSAGE);
					} else {
						JOptionPane.showMessageDialog(null, "注册失败!", "提示信息", JOptionPane.INFORMATION_MESSAGE);
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
