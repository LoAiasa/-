/**
 * 中北大学（u）刘鑫
 */
package Frame;
/**
 * 软件学院（c） 2022-2023.
 */
//管理员界面
// fr.setLocationRelativeTo(null);                  //让窗体居中显示
import db.ConnectToDataBase;

import javax.swing.*;
import java.awt.Font;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import java.awt.Color;
import java.awt.Dimension;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class AdmFrame {

	private JFrame frame;//窗体
	String res = "";
	static ExpressTable expresstable;//整个快递信息的表格数据，含 表头和数据
	private List<String> tableHeadList;//将表头数据存放在ArrayList当中
	static Vector<Vector<String>> tableData = new Vector<Vector<String>>();//将表格数据存放到Vector当中，Vector和ArrayList很相似，
	// 但Vector是线程安全的，ArrayList是非线程安全的

	public AdmFrame() throws SQLException, ParseException {
		init();//初始化
		frame.setVisible(true);//可视化
	}

	private void init() throws SQLException, ParseException {
		frame = new JFrame();//new一个窗体对象
		frame.getContentPane().setBackground(Color.WHITE);//设置窗体的颜色
		frame.setTitle("管理员界面");
		frame.setBounds(100, 100, 962, 690);
		frame.setLocationRelativeTo(null);//让窗体居中显示
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);///用户单击窗口的关闭按钮时程序执行的操作,退出应用程序
		frame.getContentPane().setLayout(null);//设置空布局
		JLabel lblNewLabel = new JLabel("欢迎使用快递驿站管理系统");
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setFont(new Font("宋体", Font.BOLD, 27));
		//Font是JAVA中的字体类，PLAIN表示的是:普通样式常量。其他可用样式为:BOLD :粗体样式常量 ,ITALIC: 斜体样式常量.
		lblNewLabel.setBounds(321, 13, 710, 66);
		frame.getContentPane().add(lblNewLabel);
		//初始化表头集合tableHeadList
		List<String> tableHeadList = new ArrayList<String>();
		//其实本质上就是给ArrarList当中添加数据
		tableHeadList.add("expressId");
		tableHeadList.add("company");
		tableHeadList.add("name");
		tableHeadList.add("phone");
		tableHeadList.add("position");
		tableHeadList.add("time");
		//将存放在表头当中的数据转化到Vector当中
		Vector<String> tableHeader = new Vector<String>(tableHeadList);
		//初始化整个表格
		expresstable = new ExpressTable(tableData, tableHeader);
		//设置表格列的宽度
		expresstable.getColumnModel().getColumn(0).setPreferredWidth(350);
		expresstable.getColumnModel().getColumn(1).setPreferredWidth(350);
		expresstable.getColumnModel().getColumn(2).setPreferredWidth(350);
		expresstable.getColumnModel().getColumn(3).setPreferredWidth(350);
		expresstable.getColumnModel().getColumn(4).setPreferredWidth(350);
		expresstable.getColumnModel().getColumn(5).setPreferredWidth(350);
		//容纳表格的Panel
		JPanel tablepanel = new JPanel();
		tablepanel.setBounds(58, 150, 850, 360);
		tablepanel.add(expresstable.getTableHeader());//将表头添加到面板上
		JScrollPane scrollPane = new JScrollPane(expresstable);//将文本内容添加到滚动条上
		scrollPane.setPreferredSize(new Dimension(850, 360));//设置滚动条的大小
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS); // 设置垂直滚动条一直显示
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER); // 设置水平滚动条从不显示
		tablepanel.add(scrollPane);//将滚动条添加到面板上
		frame.getContentPane().add(tablepanel);//再将面板放到窗体上

		JComboBox<String> l_tid = new JComboBox();//下拉框
		l_tid.addItem("快递编号");
		l_tid.addItem("收件人姓名");
		l_tid.addItem("收件人电话");
		l_tid.addItem("超时快递");
		l_tid.setFont(new Font("宋体", Font.PLAIN, 18));
		l_tid.setBounds(40, 71, 120, 41);//设置下拉框的尺寸和位置
		frame.getContentPane().add(l_tid);

		JTextField t_tid = new JTextField();//文本框
		t_tid.setBounds(175, 71, 105, 41);//设置文本框的尺寸和位置
		frame.getContentPane().add(t_tid);
		t_tid.setColumns(10);
//对超过两天没有取快递的用户进行弹窗提醒
		try {
			Connection conn = ConnectToDataBase.getDataBaseConnection();//连接数据库
			String sql = "select * from service";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			Vector<String> record = null;
			while (rs.next()) {
				String time_service = rs.getString("time");
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date d_service = sdf.parse(time_service);
				long time_k_d = d_service.getTime();//变成毫秒
				long time_now = System.currentTimeMillis();
				long dert_time = time_now - time_k_d;
				if (dert_time > 1000 * 60 * 60 * 24 * 2) {
					res += rs.getString("name");
					res += "\n";
				}
				record = new Vector<String>();//重置record
				for (int i = 0; i < 6; i++) {
					record.add(rs.getString(i + 1));
				}
				tableData.add(record);
			}
			conn.close();//关闭连接
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//刷新表格内容
		expresstable.validate();
		expresstable.updateUI();
		//弹窗提醒
		if(res != "") {
			JOptionPane.showMessageDialog(null, "用户：\n" + res + "快递已存放超过两天，请尽快取件！", "超时快递提醒", JOptionPane.WARNING_MESSAGE);
		}

//查询
		JButton b_find = new JButton("查询");
		b_find.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					Connection conn = ConnectToDataBase.getDataBaseConnection();//连接数据库
					String tid = t_tid.getText();

					String sql = "";
					boolean flag = false;//做标记
					switch (l_tid.getSelectedIndex()) {
						case 0:
							sql = "select * from service where expressID = ?";
							break;
						case 1:
							sql = "select * from service where name = ?";
							break;
						case 2:
							sql = "select * from service where phone = ?";
							break;
						case 3:
							sql = "select * from service";
							flag = true;
							break;
					}

					PreparedStatement pstmt = conn.prepareStatement(sql);
					if (flag == false) {
						pstmt.setString(1, tid);//前面埋下的坑，在这儿来填
					}
					tableData.clear();//清除表格原有的数据
					ResultSet rs = pstmt.executeQuery();//执行sql语句
					Vector<String> record = null;
					//如果找了一圈没有找到，那就会给出提示
					if (!rs.next()) {
						if (!(tid.equals(""))) {
							JOptionPane.showMessageDialog(null, "管理员尚未添加快递,请稍后再试",
									"系统信息", JOptionPane.WARNING_MESSAGE);
							return;
						}
					} else {

						rs = pstmt.executeQuery();//重置rs 防止跳过第一次
						while (rs.next()) {//迭代遍历
							if (flag == true) {
								record = new Vector<String>();//重置record
								String time_service = rs.getString("time");
								SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//自定义日期格式
								Date d_service = sdf.parse(time_service);
								long time_k_d = d_service.getTime();
								long time_now = System.currentTimeMillis();
								long dert_time = time_now - time_k_d;
								if (dert_time > (1000 * 60 * 60 * 24 * 2)) {
									for (int i = 0; i < 6; i++) {
										record.add(rs.getString(i + 1));
									}
									tableData.add(record);
								}
							} else {
								record = new Vector<String>();//重置record
								for (int i = 0; i < 6; i++) {
									record.add(rs.getString(i + 1));
								}
								tableData.add(record);
							}
						}
						conn.close();
					}
					if (tid.equals("")) {
						String sql1 = "select * from service";
						PreparedStatement pstmt1 = conn.prepareStatement(sql1);//将这条sql语句放到数据库当中
						rs = pstmt1.executeQuery();//然后sql语句在数据库当中执行查询操作
						tableData.clear();//清空表格
						//ResultSet对象具有指向其当前数据行的指针。开始，指针被置于第一行。.next()方法将指针移动到下一行，
						// 然后while循环迭代遍历ResultSet对象。
						//这么说吧，现在已经从数据库当中取出来了想要取得东西，只不过是以ResultSet对象的形式存放，和While连用迭代遍历
						while (rs.next()) {
							record = new Vector<String>();//重置record
							for (int i = 0; i < 6; i++) {
								record.add(rs.getString(i + 1));
							}
							tableData.add(record);
						}
						//刷新
						expresstable.validate();
						expresstable.updateUI();
						return;
					}
				} catch (SQLException e) {
					e.printStackTrace();
				} catch (ParseException e) {
					e.printStackTrace();
				}
				//更新整个表格
				expresstable.validate();
				expresstable.updateUI();

			}
		});
		b_find.setBounds(295, 71, 129, 41);
		frame.getContentPane().add(b_find);
//确认修改
		JButton b_update = new JButton("确认修改");
		b_update.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int row = expresstable.getSelectedRow();
				int column = expresstable.getSelectedColumn();

				String val = tableData.get(row).get(column);
				String id = tableData.get(row).get(0);

				try {
					Connection conn = ConnectToDataBase.getDataBaseConnection();//连接数据库
					String sql = "UPDATE service SET " + tableHeadList.get(column) + " = ? WHERE expressID = ?";
					PreparedStatement pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, val);
					pstmt.setString(2, id);
					int flag = pstmt.executeUpdate();//执行语句
					if (flag == 1) {
						JOptionPane.showMessageDialog(null, "修改成功!", "提示信息", JOptionPane.INFORMATION_MESSAGE);

					} else {
						JOptionPane.showMessageDialog(null, "修改失败", "提示信息", JOptionPane.INFORMATION_MESSAGE);

					}
					conn.close();
				} catch (SQLException e1) {

					e1.printStackTrace();
				}
				expresstable.validate();
				expresstable.updateUI();
			}
		});
		b_update.setBounds(461, 71, 129, 41);
		frame.getContentPane().add(b_update);
//添加快递
		JButton button_1 = new JButton("添加快递");
		button_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new AddFrame();
				//更新表格数据
				expresstable.validate();
				expresstable.updateUI();

			}
		});
		button_1.setBounds(629, 71, 129, 41);
		frame.getContentPane().add(button_1);
//删除
		JButton b_delete = new JButton("删除");
		b_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int row = expresstable.getSelectedRow();//获取被选行
				String id = tableData.get(row).get(0);//获取被选行的id
				try {
					Connection conn = ConnectToDataBase.getDataBaseConnection();//连接数据库
					String sql = "delete from service where expressID = ?";
					PreparedStatement pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, id);
					pstmt.executeUpdate();
					tableData.remove(row); //从表格中移出一行
				} catch (SQLException e1) {

					e1.printStackTrace();
				}

				//更新表格数据
				expresstable.validate();
				expresstable.updateUI();
			}
		});
		b_delete.setBounds(789, 71, 129, 41);
		frame.getContentPane().add(b_delete);

//提醒超时
		JButton b_tx = new JButton("提醒超时");
		b_tx.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "提醒成功");
				//更新表格数据
				expresstable.validate();
				expresstable.updateUI();
			}

		});
		b_tx.setBounds(789, 550, 129, 41);
		frame.getContentPane().add(b_tx);
	}

}
