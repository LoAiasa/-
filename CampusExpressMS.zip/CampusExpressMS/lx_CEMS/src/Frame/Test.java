/**
 * 中北大学（u）刘鑫
 */
package Frame;

/**
 
 * @author liuxin
 * @version 1.0
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        new LoginFrame();

	}

}
