/**
 * 中北大学（u）刘鑫
 */
package Frame;

/**
 * 软件学院（c） 2022-2023.
 */

import db.ConnectToDataBase;

import javax.swing.*;

import java.awt.Font;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import java.awt.Color;
import java.awt.Dimension;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import static Frame.LoginFrame.userId;

/**
 * @author liuxin
 * @veride1.0
 * 
 */
public class UserFrame extends JFrame {
	private String ExpressId;
	private JFrame frame;
	private JTextField t_tid;//单行文本框
	public String res = "";
	static ExpressTable expresstable;//整个快递信息的表格数据，含 表头和数据
	private List<String> tableHeadList;//存放在表头的集合List
	static Vector<Vector<String>> tableData = new Vector<Vector<String>>();//表格数据

	public UserFrame() throws ParseException {
		init();
		frame.setVisible(true);
	}

	private void init() throws ParseException {
		frame = new JFrame();

		frame.getContentPane().setBackground(Color.WHITE);
		//frame.getContentPane().setForeground(Color.WHITE);
		frame.setTitle("用户界面");
		frame.getContentPane().setLayout(null);//自定义布局,最重要的一句话
		frame.setBounds(100, 100, 962, 548);//100 100 962 548
		frame.setLocationRelativeTo(null);//让窗体居中显示
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JLabel lblNewLabel = new JLabel("欢迎浏览快递信息");
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setFont(new Font("微软雅黑", Font.PLAIN, 24));
		lblNewLabel.setBounds(400, 13, 710, 66);
		frame.getContentPane().add(lblNewLabel);

		//初始化表头集合tableHeadList
		tableHeadList = new ArrayList<String>();
		tableHeadList.add("expressId");
		tableHeadList.add("company");
		tableHeadList.add("name");
		tableHeadList.add("phone");
		tableHeadList.add("position");
		tableHeadList.add("time");

		//将list转化为Vector
		Vector<String> tableHeader = new Vector<String>(tableHeadList);

		//初始化整个表格
		expresstable = new ExpressTable(tableData, tableHeader);

		//设置表格列的宽度
		expresstable.getColumnModel().getColumn(0).setPreferredWidth(350);
		expresstable.getColumnModel().getColumn(1).setPreferredWidth(350);
		expresstable.getColumnModel().getColumn(2).setPreferredWidth(350);
		expresstable.getColumnModel().getColumn(3).setPreferredWidth(350);
		expresstable.getColumnModel().getColumn(4).setPreferredWidth(350);
		expresstable.getColumnModel().getColumn(5).setPreferredWidth(350);

		//容纳表格的Panel
		JPanel tablepanel = new JPanel();

		tablepanel.setBounds(58, 125, 850, 363);//设置大小和位置
		tablepanel.add(expresstable.getTableHeader());

		JScrollPane scrollPane = new JScrollPane(expresstable);//将表格添加到srollPane中
		scrollPane.setPreferredSize(new Dimension(850, 360));//设置Pane大小
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS); // 设置垂直滚动条一直显示
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER); // 设置水平滚动条从不显示
		tablepanel.add(scrollPane);
		frame.getContentPane().add(tablepanel);


		JComboBox<String> l_tid = new JComboBox();
		l_tid.addItem("快递单号");
		l_tid.addItem("手机号");
		l_tid.setFont(new Font("宋体", Font.PLAIN, 18));
		l_tid.setBounds(58, 75, 120, 41);
		frame.getContentPane().add(l_tid);

		t_tid = new JTextField();
		t_tid.setBounds(200, 73, 110, 41);
		frame.getContentPane().add(t_tid);
		t_tid.setColumns(10);

		try {
			Connection conn = ConnectToDataBase.getDataBaseConnection();//连接数据库
			String sql = "select xingming from register where yonghuming = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			ResultSet rs = pstmt.executeQuery();

			String str = "";
			while(rs.next()){
				str = rs.getString("xingming");
			}
			String sql1 = "select * from service where name = ?";
			PreparedStatement pstmt1 = conn.prepareStatement(sql1);
			pstmt1.setString(1,str);
			ResultSet rs1 = pstmt1.executeQuery();
			Vector<String> record = null;
			while (rs1.next()) {
				String time_service = rs1.getString("time");

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

				Date d_service = sdf.parse(time_service);

				long time_k_d = d_service.getTime();

				long time_now = System.currentTimeMillis();
				long dert_time = time_now - time_k_d;
				if (dert_time > 1000 * 60 * 60 * 24 * 2) {
					res = rs1.getString("name");
				}
				record = new Vector<String>();//重置record
				for (int i = 0; i < 6; i++) {
					record.add(rs1.getString(i + 1));
				}
				tableData.add(record);
			}
			if(res != "") {
				JOptionPane.showMessageDialog(null, "用户：\n" + res + "\n您的快递超时未取，请尽快领取！", "超时快递提醒", JOptionPane.WARNING_MESSAGE);
			}
			conn.close();//关闭连接
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		//刷新表格内容
		expresstable.validate();
		expresstable.updateUI();

		JButton b_find = new JButton("查询");
		b_find.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg) {
				try {
					Connection conn = ConnectToDataBase.getDataBaseConnection();//连接数据库
					String sql = "select xingming from register where yonghuming = ?";
					PreparedStatement pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, userId);
					ResultSet rs = pstmt.executeQuery();
					String str = "";
					while(rs.next()){
						str = rs.getString("xingming");
					}

					String sql1 = "select * from service where name = ?";
					PreparedStatement pstmt1 = conn.prepareStatement(sql1);
					pstmt1.setString(1,str);
					ResultSet rs1 = pstmt1.executeQuery();

					String tid = t_tid.getText();
					if (tid.equals("")) {
						Vector<String> record;
						tableData.clear();
						while (rs1.next()) {

							record = new Vector<String>();//重置record
							for (int i = 0; i < 6; i++) {
								record.add(rs1.getString(i + 1));
							}
							tableData.add(record);
						}
						//刷新表格内容
						expresstable.validate();
						expresstable.updateUI();
						return;
					}
					String sql2 = "";
					switch (l_tid.getSelectedIndex()) {
						case 0:
							sql2 = "select * from service where name = ? and expressId = ?";
							break;
						case 1:
							sql2 = "select * from service where name = ? and phone = ?";
							break;
					}
					PreparedStatement pstmt2 = conn.prepareStatement(sql2);
					pstmt2.setString(1, str);
					pstmt2.setString(2, tid);
					tableData.clear();//清除表格原有的数据
					ResultSet rs2 = pstmt2.executeQuery();//执行sql语句
					Vector<String> record = null;//存放表格数据记得的集合
					if (!(rs2.next())) {
						JOptionPane.showMessageDialog(null, "你的快递还未派送，请耐心等待！！！", "系统信息",
								JOptionPane.WARNING_MESSAGE);
						return;
					} else {

						rs2 = pstmt2.executeQuery();//重置rs 防止跳过第一次
						while (rs2.next()) {
							record = new Vector<String>();//重置record
							for (int i = 0; i < 6; i++) {
								record.add(rs2.getString(i + 1));
							}
							tableData.add(record);
						}
						conn.close();


					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//更新整个表格
				expresstable.validate();
				expresstable.updateUI();

			}

		});
		b_find.setBounds(330, 71, 129, 41);
		frame.getContentPane().add(b_find);

		JButton b_change = new JButton("修改信息");
		b_change.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int row = expresstable.getSelectedRow();
				int column = expresstable.getSelectedColumn();

				String val = tableData.get(row).get(column);
				String id = tableData.get(row).get(0);

				try {
					Connection conn = ConnectToDataBase.getDataBaseConnection();//连接数据库
					String sql = "UPDATE service SET " + tableHeadList.get(column) + " = ? WHERE expressId = ?";
					PreparedStatement pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, val);
					pstmt.setString(2, id);
					int flag = pstmt.executeUpdate();//执行语句
					if (flag == 1) {
						if(column == 2 || column == 3 ) {
							JOptionPane.showMessageDialog(null, "修改成功!", "提示信息", JOptionPane.INFORMATION_MESSAGE);
						}
					} else {
						JOptionPane.showMessageDialog(null, "修改失败", "提示信息", JOptionPane.INFORMATION_MESSAGE);

					}
					conn.close();
				} catch (SQLException e1) {

					e1.printStackTrace();
				}
				expresstable.validate();
				expresstable.updateUI();
			}

		});
		b_change.setBounds(490, 71, 129, 41);
		frame.getContentPane().add(b_change);

		JButton b_send = new JButton("寄件");
		b_send.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new SendFrame();
				dispose();

			}
		});

		b_send.setBounds(640, 71, 129, 41);
		frame.getContentPane().add(b_send);


		JButton b_pick = new JButton("取件");
		b_pick.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PickFrame();
				dispose();

			}
		});
		b_pick.setBounds(785, 71, 129, 41);
		frame.getContentPane().add(b_pick);



	}
}

