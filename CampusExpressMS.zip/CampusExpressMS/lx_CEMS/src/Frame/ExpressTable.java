/**
 * 中北大学（u）刘鑫
 */
package Frame;

import java.util.Vector;

import javax.swing.JTable;

/**
 *
 * @author liuxin
 * @version 1.0
 */
//JTable中存储数据库中ExpressTable的信息,但是不可以随意修改。
public class ExpressTable extends JTable{
  public ExpressTable(Vector expressInformation,Vector title){//表中的数据和表头
	  super(expressInformation,title);//通过构造方法初始化表头和数据
  }

    public boolean isCellEditable(int row,int column) {
        if(column==0)
            return false;
        else
            return true;
    }
  

}
