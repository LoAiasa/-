package Frame;

import db.ConnectToDataBase;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author liuxin
 * @version 1.0
 */
 class LoginFrame extends JFrame {
	public static String userId;
	private JLabel yonghuming,leixing,mima;
	private JTextField ID;
	private JPasswordField Password;
	private JButton login,reset,register;
	public LoginFrame() {
		this.setTitle("登录窗体");
		this.setSize(380,300);
		this.setLocation(200,100);
		this.setResizable(false);
		this.setLocationRelativeTo(null);//让窗体居中显示
		init();
		this.setVisible(true);
	}
	public void init(){
		this.setLayout(null);//自定义布局,这是最关键的一句话
		yonghuming=new JLabel("用户名",JLabel.CENTER);
		leixing=new JLabel("用户类型",JLabel.CENTER);
		mima= new JLabel("密码",JLabel.CENTER);

		ID=new JTextField();

		JComboBox<String> Type = new JComboBox<String>();
		Type.addItem("-------------请选择------------");
		Type.addItem("管理员");
		Type.addItem("用户");
		Type.setSelectedIndex(0);//0 / 1 / 2

		Password=new JPasswordField();

		login=new JButton("登录");
		reset=new JButton("重置");
		register=new JButton("注册");

		login.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String Id = ID.getText();
				userId = Id;
				String password = Password.getText();
				String type = (String) Type.getSelectedItem();

				String password1 = null,type1 = null;
				try {
					Connection conn = ConnectToDataBase.getDataBaseConnection();//连接数据库
					String sql = "SELECT * FROM register where yonghuming = ?";

					PreparedStatement pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, Id);
					ResultSet rs = pstmt.executeQuery();//执行语句

					while(rs.next()) {//迭代遍历
						type1 = (String)rs.getString(3);
						password1 = (String)rs.getString(4);
					}
				} catch(SQLException e1) {
					e1.printStackTrace();
				}
				if(type.equals("") || password.equals("") || Id .equals("")){
					JOptionPane.showMessageDialog(null, "所填信息不能为空", "提示信息", JOptionPane.INFORMATION_MESSAGE);
				}
				if(password.equals(password1)&&type.equals(type1)) {
					if(type1.equals("用户")) {
						try {
							new UserFrame();
						} catch (ParseException ex) {
							throw new RuntimeException(ex);
						}
						dispose();
					}
					else {
						try {
							new AdmFrame();
						} catch (SQLException ex) {
							throw new RuntimeException(ex);
						} catch (ParseException ex) {
							throw new RuntimeException(ex);
						}
						dispose();
					}
				}
				if(!(password.equals(password1)&&type.equals(type1)) &&!(type.equals("") || password.equals("") || Id .equals(""))){
					JOptionPane.showMessageDialog(null, "账号或密码错误，如果没有账号，请注册","错误信息",JOptionPane.WARNING_MESSAGE);
					return;
				}
			}
		});

		register.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new RegisterFrame();
				//dispose();
			}
		});

		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ID.setText("");
				Password.setText("");
				Type.setSelectedIndex(-1);
			}
		});

		JPanel p=new JPanel();
		p.setBounds(5, 5, 350, 185);
		p.setLayout(new GridLayout(3,2,5,5));//网格布局
		p.add(yonghuming);
		p.add(ID);

		p.add(leixing);
		p.add(Type);

		p.add(mima);
		p.add(Password);

		this.add(p);

		p=new JPanel();
		p.setBounds(5, 205, 350, 50);
		p.setLayout(new GridLayout(1,3,5,5));//网格布局
		p.add(login);
		p.add(reset);
		p.add(register);
		this.add(p);
	}
	
	}

