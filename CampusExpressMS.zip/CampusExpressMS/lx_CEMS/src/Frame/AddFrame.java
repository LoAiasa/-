/**
 * 中北大学（u）刘鑫
 */
package Frame;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import db.ConnectToDataBase;

/**
 *
 * @author liuxin
 * @version 1.0
 */
public class AddFrame extends JFrame{
	private JLabel L_expressId,L_company,L_name,L_phone,L_position,L_time;
    private JTextField t_expressId,t_company,t_name,t_phone,t_position,t_time;
    ButtonGroup bg;
    private JButton b_add,b_reset;

public AddFrame() {
	this.setTitle("添加快递");
	this.setSize(300, 450);
	this.setLocation(100, 150);
	init();
	this.setResizable(false);
	this.setVisible(true);
}

public void init() {
	this.setLayout(new GridLayout(7, 2, 5, 5));
	L_expressId=new JLabel("快递单号",JLabel.CENTER);
	L_company=new JLabel("快递公司",JLabel.CENTER);
	L_name=new JLabel("收件人姓名",JLabel.CENTER);
	L_phone=new JLabel("收件人电话",JLabel.CENTER);
	L_position=new JLabel("存放位置",JLabel.CENTER);
	L_time=new JLabel("存放时间",JLabel.CENTER);
	t_expressId=new JTextField();
	t_company=new JTextField();
	t_name=new JTextField();
	t_phone=new JTextField();
	t_position=new JTextField();
	t_time=new JTextField();
     b_add = new JButton("添加");
     b_add.addActionListener(new ActionListener() {//事件处理
			@Override
			public void actionPerformed(ActionEvent e) {

				addExpress();
				dispose();//关闭窗体
			}
     });

     b_reset = new JButton("重置");
     b_reset.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				t_expressId.setText("");
				t_company.setText("");
				t_name.setText("");
				t_phone.setText("");
				t_position.setText("");
				t_time.setText("");
				
			}
     	
     });
     this.add(L_expressId);
     this.add(t_expressId);
     
     this.add(L_company);
     this.add(t_company);
     
     this.add(L_name);
     this.add(t_name);

     this.add(L_phone);
     this.add(t_phone);
     
     this.add(L_position);
     this.add(t_position);
     
     this.add(L_time);
     this.add(t_time);
     
     this.add(b_add);
     this.add(b_reset);

}
    public void addExpress() {
	    //trim() 方法用于删除字符串的头尾空白符，空白符包括：空格、制表符 tab、换行符等其他空白符等。
    	String expressId=t_expressId.getText().trim();
    	String company=t_company.getText().trim();
    	String name=t_name.getText().trim();
    	String phone=t_phone.getText().trim();
    	String position=t_position.getText().trim();
		String time=t_time.getText().trim();
		try {
			Connection conn = ConnectToDataBase.getDataBaseConnection();//连接数据库
			String sql1 = "SELECT * FROM service WHERE expressID = ?";
			String sql = "INSERT INTO service VALUES(?,?,?,?,?,?)";
		    PreparedStatement pstm1 = conn.prepareStatement(sql1);

		    pstm1.setString(1, expressId);
		    ResultSet rs = pstm1.executeQuery();
		    if(rs.next()) {
		    	JOptionPane.showMessageDialog(null,"添加失败!，该快递单号已存在","提示信息",JOptionPane.INFORMATION_MESSAGE);
		    } else {
		    PreparedStatement pstm=conn.prepareStatement(sql);
		    pstm.setString(1,expressId);
		    pstm.setString(2,company);
		    pstm.setString(3,name);
		    pstm.setString(4,phone);
		    pstm.setString(5,position);
			pstm.setString(6,time);
		    int flag=pstm.executeUpdate();
			if(time.equals("") || position.equals("") || phone.equals("") || name.equals("") || company.equals("") ||expressId.equals("")){
				JOptionPane.showMessageDialog(null,"添加失败！","提示信息",JOptionPane.INFORMATION_MESSAGE);
			}
		    if(flag==1) {
		    	JOptionPane.showMessageDialog(null,"添加成功!","提示信息",JOptionPane.INFORMATION_MESSAGE);
		    	
		    	//更新表格数据
		    	AdmFrame.tableData.clear();
				String sql2 = "select * from service";
				PreparedStatement pstmt3 = conn.prepareStatement(sql2);
				ResultSet rs2 = pstmt3.executeQuery();
				Vector<String> record;
				while(rs2.next())
				{
					record = new Vector<String>();//重置record
					for(int i = 0; i < 6 ; i++) {
						record.add(rs2.getString(i+1));
					}
					AdmFrame.tableData.add(record);
				}
				
				//刷新数据
				AdmFrame.expresstable.validate();
				AdmFrame.expresstable.updateUI();
				
		    } else {
		    	JOptionPane.showMessageDialog(null,"添加失败！","提示信息",JOptionPane.INFORMATION_MESSAGE);
		    }
		    }
    	
    } catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
}