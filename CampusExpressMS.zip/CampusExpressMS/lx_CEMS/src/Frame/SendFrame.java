package Frame;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: LiuXin
 * @Date: 2022/12/21/14:07
 * @Description:
 */

import db.ConnectToDataBase;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import static Frame.LoginFrame.userId;

public class SendFrame extends JFrame{
    private JLabel L_deliveryman,L_deliveryphone,L_sum,L_recipients,L_recipientsphone,L_address;
    private JTextField t_deliveryman,t_deliveryphone,t_sum,t_recipients,t_recipientsphone,t_address;
    private JButton b_add,b_reset;

    public SendFrame() {
        this.setTitle("寄件");
        this.setSize(300, 450);
        this.setLocation(200, 150);
        init();
        this.setVisible(true);
    }
    public void init() {
        this.setLayout(new GridLayout(7, 2, 5, 5));//网格布局
        L_deliveryman=new JLabel("寄件人",JLabel.CENTER);
        L_deliveryphone=new JLabel("寄件人电话",JLabel.CENTER);
        L_sum=new JLabel("件数",JLabel.CENTER);
        L_recipients=new JLabel("收件人",JLabel.CENTER);
        L_recipientsphone=new JLabel("收件人电话",JLabel.CENTER);
        L_address=new JLabel("地址",JLabel.CENTER);

        t_deliveryman=new JTextField();
        t_deliveryphone=new JTextField();
        t_sum=new JTextField();
        t_recipients=new JTextField();
        t_recipientsphone=new JTextField();
        t_address=new JTextField();


        b_add = new JButton("寄件");
        b_add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                try {
                    addExpress();
                    dispose();//关闭该窗体，释放该窗体占有的资源
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }

        });
        b_reset = new JButton("清空");
        b_reset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                t_deliveryman.setText("");
                t_deliveryphone.setText("");
                t_sum.setText("");
                t_recipients.setText("");
                t_recipientsphone.setText("");
                t_address.setText("");

            }

        });
        this.add(L_deliveryman);
        this.add(t_deliveryman);

        this.add(L_deliveryphone);
        this.add(t_deliveryphone);

        this.add(L_sum);
        this.add(t_sum);

        this.add(L_recipients);
        this.add(t_recipients);

        this.add(L_recipientsphone);
        this.add(t_recipientsphone);

        this.add(L_address);
        this.add(t_address);

        this.add(b_add);
        this.add(b_reset);
    }
    public void addExpress() throws SQLException {
        String deliveryman=t_deliveryman.getText().trim();
        String deliveryphone=t_deliveryphone.getText().trim();
        String sum=t_sum.getText().trim();
        String recipients=t_recipients.getText().trim();
        String recipientsphone=t_recipientsphone.getText().trim();
        String address=t_address.getText().trim();
        try {
            Connection conn = ConnectToDataBase.getDataBaseConnection();//连接数据库
            String sql = "INSERT INTO service VALUES(?,?,?,?,?,?)";
            PreparedStatement pstm = conn.prepareStatement(sql);

            Random random = new Random();
            int a = random.nextInt(3);
            int b = random.nextInt(3);
            int c = random.nextInt(3);
            String str = "s" + a + b+ c;
            //System.out.println(str);
            char q = (char)(random.nextInt(26) + 97);
            //System.out.println(q + "区" + str + "号柜");
            Date now = new Date();
            //System.out.println(now);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String str1 = sdf.format(now);
            //System.out.println(str1);
            pstm.setString(1,str);
            pstm.setString(2,"圆通");
            pstm.setString(3,recipients);
            pstm.setString(4,recipientsphone);
            pstm.setString(5,q + "区" + str + "号柜");
            pstm.setString(6,str1);
            int flag=pstm.executeUpdate();
            String sql2 = "select xingming from register where yonghuming = ?";
            PreparedStatement pstmt2 = conn.prepareStatement(sql2);
            pstmt2.setString(1, userId);
            ResultSet rs2 = pstmt2.executeQuery();

            String str2 = "";
            while(rs2.next()){
                str2 = rs2.getString("xingming");
            }
            if(flag==1) {
                if( deliveryphone.equals("") || deliveryman.equals("") || sum.equals("") || address.equals("") || recipients.equals("") || recipientsphone.equals("")) {
                    JOptionPane.showMessageDialog(null, "所填信息不能为空", "提示信息", JOptionPane.INFORMATION_MESSAGE);
                }else {
                    JOptionPane.showMessageDialog(null, "寄件成功!", "提示信息", JOptionPane.INFORMATION_MESSAGE);
                    AdmFrame.tableData.clear();
                    String sql1 = "select * from service where name = ?";
                    PreparedStatement pstmt1 = conn.prepareStatement(sql1);
                    pstmt1.setString(1,str2);
                    ResultSet rs1 = pstmt1.executeQuery();
                    Vector<String> record;
                    while (rs1.next()) {
                        record = new Vector<String>();//重置record
                        for (int i = 0; i < 6; i++) {
                            record.add(rs1.getString(i + 1));
                        }
                        UserFrame.tableData.add(record);
                    }

                    //刷新表格数据
                    UserFrame.expresstable.validate();
                    UserFrame.expresstable.updateUI();
                }
                }else{
                JOptionPane.showMessageDialog(null, "寄件失败！", "提示信息", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }
}

