package Frame;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: LiuXin
 * @Date: 2022/12/21/14:01
 * @Description:
 */
import db.ConnectToDataBase;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.*;

import static Frame.LoginFrame.userId;
import static Frame.UserFrame.expresstable;
import static Frame.UserFrame.tableData;

public class PickFrame extends JFrame{
    private JTextField t_pick;
    private JButton b_pick,b_reset;
    public  PickFrame() {
        this.setTitle("取件");
        this.setSize(300, 150);
        this.setLocation(1200, 300);
        init();
        this.setVisible(true);
    }
    public void init() {
        this.setLayout(new GridLayout(2,2,5,5));//网格布局
        JComboBox<String> j_pick = new JComboBox<>();//下拉框
        j_pick.addItem("---------请选择---------");
        j_pick.addItem("快递单号");
        j_pick.addItem("存放位置");
        j_pick.addItem("收件人电话");
        t_pick = new JTextField();
        b_pick = new JButton("取件");
        b_reset = new JButton("清空");
        b_pick.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String str1 = t_pick.getText().trim();

                try {
                    Connection conn = ConnectToDataBase.getDataBaseConnection();//连接数据库

                    String sql = "select xingming from register where yonghuming = ?";
                    PreparedStatement pstmt = conn.prepareStatement(sql);
                    pstmt.setString(1, userId);
                    ResultSet rs = pstmt.executeQuery();
                    String str = "";
                    while (rs.next()) {
                        str = rs.getString("xingming");
                    }
                    String sql1 = "";
                    switch (j_pick.getSelectedIndex()) {
                        case 0:
                            JOptionPane.showMessageDialog(null, "所填信息不能为空", "提示信息", JOptionPane.INFORMATION_MESSAGE);
                            break;
                        case 1:
                            sql1 = "delete from service where name = ? and expressId = ?";
                            break;
                        case 2:
                            sql1 = "delete from service where name = ? and position= ?";
                            break;
                        case 3:
                            sql1 = "delete from service where name = ? and phone = ?";
                            break;
                    }
                    PreparedStatement pstmt1 = conn.prepareStatement(sql1);
                    pstmt1.setString(1, str);
                    pstmt1.setString(2, str1);
                    int flag = pstmt1.executeUpdate();//执行sql语句*/
                    if(str1.equals("")){
                        JOptionPane.showMessageDialog(null,"所填信息不能为空","提示信息",JOptionPane.INFORMATION_MESSAGE);
                    }else {
                        if (flag == 1) {
                            JOptionPane.showMessageDialog(null, "取件成功!", "提示信息", JOptionPane.INFORMATION_MESSAGE);
                            //更新表格数据
                            UserFrame.tableData.clear();
                            String sql2 = "select * from service where name = ?";
                            PreparedStatement pstmt2 = conn.prepareStatement(sql2);
                            pstmt2.setString(1, str);
                            ResultSet rs2 = pstmt2.executeQuery();
                            Vector<String> record;
                            while (rs2.next()) {
                                record = new Vector<String>();//重置record
                                for (int i = 0; i < 6; i++) {
                                    record.add(rs2.getString(i + 1));
                                }
                                AdmFrame.tableData.add(record);

                            }
                            //刷新表格数据
                            UserFrame.expresstable.validate();
                            UserFrame.expresstable.updateUI();


                        } else {
                            JOptionPane.showMessageDialog(null, "取件失败！", "提示信息", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                }catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
            });


        b_reset.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                t_pick.setText("");
                j_pick.setSelectedIndex(0);
            }
        });
        this.add(j_pick);
        this.add(t_pick);
        this.add(b_pick);
        this.add(b_reset);

    }
        }

